#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#include "Bibliotecas/Cuenta.h"
#include "Bibliotecas/Cliente.h"
#include "Bibliotecas/NodoCliente.h"

#include "Bibliotecas/ListaTAD.h"

#include "Bibliotecas/funciones.h"

int main(){
    struct NodoCliente *listaClientes,*listaClientesSaldoPositivo,
        *listaClientesSaldoNegativo;
    //struct ListaTAD lista;
    cargarClientes("ArchivosDeDatos/clientes.csv",listaClientes);
    emitirReporte("ArchivosDeReportes/InicialClientes.txt",
        "LISTADO INICIAL DE CLIENTES",listaClientes);
    completarCuentas("ArchivosDeDatos/cuentas.csv",listaClientes);
    emitirReporte("ArchivosDeReportes/InicialClientesCuentas.txt",
        "LISTADO INICIAL DE CLIENTES Y CUENTAS",listaClientes);
    completarTransacciones("ArchivosDeDatos/transacciones.csv",listaClientes);
    emitirReporte("ArchivosDeReportes/InicialClientesCuentasTransacciones.txt",
        "LISTADO INICIAL DE CLIENTES, CUENTAS Y TRANSACCIONES",listaClientes);
    actualizarInformacionCliente(listaClientes);
    emitirReporte("ArchivosDeReportes/ReporteCompletoClientes.txt",
        "LISTADO COMPLETO DE CLIENTES",listaClientes);
    crearNuevasListas(listaClientes,listaClientesSaldoPositivo,listaClientesSaldoNegativo);
    emitirReporte("ArchivosDeReportes/ReporteClientesSaldoPositivo.txt",
        "LISTADO DE CLIENTES CON SALDO POSITIVO",listaClientesSaldoPositivo);
    emitirReporte("ArchivosDeReportes/ReporteClientesSaldoNegativo.txt",
        "LISTADO DE CLIENTES CON SALDO NEGATIVO",listaClientesSaldoNegativo);
    return 0;
}