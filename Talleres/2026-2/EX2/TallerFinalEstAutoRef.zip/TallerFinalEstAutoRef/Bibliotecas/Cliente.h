//
// Created by svarg on 2/7/2026.
//

#ifndef TALLERFINALESTAUTOREF_CLIENTE_H
#define TALLERFINALESTAUTOREF_CLIENTE_H

struct Cliente{
    int dni;
    char *nombre;
    char tipoCliente;
    struct Cuenta *cuentas;
    int cantidadCuentas;
    double saldoTotal;
    int cantidadCuentasHabilitadas;
    int cantidadCuentasDeshabilitadas;
};
#endif //TALLERFINALESTAUTOREF_CLIENTE_H