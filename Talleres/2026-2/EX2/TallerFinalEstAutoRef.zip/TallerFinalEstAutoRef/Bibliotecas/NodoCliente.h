//
// Created by svarg on 2/7/2026.
//

#ifndef TALLERFINALESTAUTOREF_NODOCLIENTE_H
#define TALLERFINALESTAUTOREF_NODOCLIENTE_H

struct NodoCliente{
    struct Cliente cliente;
    struct NodoCliente* siguiente;
};
#endif //TALLERFINALESTAUTOREF_NODOCLIENTE_H