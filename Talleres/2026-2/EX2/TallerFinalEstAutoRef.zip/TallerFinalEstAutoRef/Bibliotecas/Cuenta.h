//
// Created by svarg on 2/7/2026.
//

#ifndef TALLERFINALESTAUTOREF_CUENTA_H
#define TALLERFINALESTAUTOREF_CUENTA_H

struct Cuenta{
    int nroCuenta;
    double saldoInicial;
    double saldoFinal;
    int cantidadRetiros;
    int cantidadDepositos;
    char estado[15];
};

#endif //TALLERFINALESTAUTOREF_CUENTA_H