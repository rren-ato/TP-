//
// Created by svarg on 2/7/2026.
//

#ifndef TALLERFINALESTAUTOREF_FUNCIONES_H
#define TALLERFINALESTAUTOREF_FUNCIONES_H

void cargarClientes(const char *nombArch,struct NodoCliente *&listaClientes);
char *procesarNombre(char *nombre, char *apePat, char *apeMat);
void procesarCadena(char *nombre);
void inicializarLista(struct NodoCliente *&listaClientes);
void insertarNodoOrdenado(const struct Cliente &datoCliente,
    struct NodoCliente *&listaClientes,bool tipoOrden);
void emitirReporte(const char *nombArch,const char *titulo,
    struct NodoCliente *listaClientes);
void completarCuentas(const char *nombArch,struct NodoCliente *listaClientes);
struct NodoCliente* buscarCliente(int dni,struct NodoCliente *listaClientes);
void actualizarEstado(double saldo,char *estado);
void completarTransacciones(const char *nombArch,struct NodoCliente *listaClientes);
void buscarCuenta(int cuenta,struct NodoCliente *listaClientes,struct NodoCliente *&clienteEncontrado,
    int &posCuenta);
void actualizarInformacionCliente(struct NodoCliente *listaClientes);
void crearNuevasListas(struct NodoCliente *listaClientes,
    struct NodoCliente *&listaClientesSaldoPositivo,struct NodoCliente *&listaClientesSaldoNegativo);
void imprimirLinea(ofstream &arch,char car,int cant);
#endif //TALLERFINALESTAUTOREF_FUNCIONES_H