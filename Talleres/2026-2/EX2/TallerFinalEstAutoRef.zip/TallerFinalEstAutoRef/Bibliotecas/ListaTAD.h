//
// Created by aml on 3/07/2026.
//

#ifndef TALLERFINALESTAUTOREF_LISTATAD_H
#define TALLERFINALESTAUTOREF_LISTATAD_H

struct ListaTAD {
    struct NodoCliente* inicio;
};
#endif //TALLERFINALESTAUTOREF_LISTATAD_H