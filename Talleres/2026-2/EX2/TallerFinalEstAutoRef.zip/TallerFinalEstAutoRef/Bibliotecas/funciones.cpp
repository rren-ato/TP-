#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

//
// Created by svarg on 2/7/2026.
//

#include <cstring>

#include "Cuenta.h"
#include "Cliente.h"
#include "NodoCliente.h"

#include "funciones.h"

#define MAX_CUENTAS 5
#define TAM_LINEA 150
#define NO_ENCONTRADO -1

void cargarClientes(const char *nombArch,struct NodoCliente *&listaClientes){
    ifstream arch(nombArch,ios::in);
    if (not arch.is_open()) {
        cout<<"El archivo "<<nombArch<<" no se pudo abrir"<<endl;
        exit(1);
    }
    struct Cliente datoCliente{};
    inicializarLista(listaClientes);
    char nombre[30],apePat[30],apeMat[30];
    while (true) {
        arch>>datoCliente.dni;
        if (arch.eof()) break;
        arch.get();
        arch.getline(nombre,30,',');
        arch.getline(apePat,30,',');
        arch.getline(apeMat,30,',');
        arch>>datoCliente.tipoCliente;
        datoCliente.nombre=procesarNombre(nombre,apePat,apeMat);
        datoCliente.cuentas=new struct Cuenta[MAX_CUENTAS]{};
        insertarNodoOrdenado(datoCliente,listaClientes,true);
    }
}

char *procesarNombre(char *nombre, char *apePat, char *apeMat){
    char aux[100] ,*ptr;
    procesarCadena(nombre);
    procesarCadena(apePat);
    procesarCadena(apeMat);
    strcpy(aux,apePat);
    strcat(aux,"/");
    strcat(aux,apeMat);
    strcat(aux,"/");
    strcat(aux,nombre);
    ptr=new char[strlen(aux)+1];
    strcpy(ptr,aux);
    return ptr;
}

void procesarCadena(char *nombre){
    bool mayus=true;
    for (int i=0;nombre[i];i++) {
        if (mayus)
            mayus=false;
        else
            nombre[i]+=((nombre[i]>='A' and nombre[i]<='Z')?('a'-'A'):0);
        if (nombre[i]==' ')
            mayus=true;
    }
}

void inicializarLista(struct NodoCliente *&listaClientes){
    listaClientes=nullptr;
}

void insertarNodoOrdenado(const struct Cliente &datoCliente,
    struct NodoCliente *&listaClientes,bool tipoOrden){
    //tipoOrden true por dni, false por saldo
    struct NodoCliente *nuevoNodo,*ptr,*ptrAnt;
    nuevoNodo=new struct NodoCliente;
    nuevoNodo->cliente=datoCliente;
    ptr=listaClientes;
    ptrAnt=nullptr;
    while (ptr) {
        if (tipoOrden) {
            if (datoCliente.dni<ptr->cliente.dni)
                break;
        }
        else {
            if (datoCliente.saldoTotal>ptr->cliente.saldoTotal)
                break;
        }
        ptrAnt=ptr;
        ptr=ptr->siguiente;
    }
    nuevoNodo->siguiente=ptr;
    if (ptrAnt)
        ptrAnt->siguiente=nuevoNodo;
    else
        listaClientes=nuevoNodo;
}


void emitirReporte(const char *nombArch,const char *titulo,
    struct NodoCliente *listaClientes){
    ofstream arch(nombArch,ios::out);
    if (not arch.is_open()) {
        cout<<"Error: el archivo "<<nombArch<<" no se pudo abrir"<<endl;
        exit(1);
    }
    struct NodoCliente *ptr=listaClientes;
    imprimirLinea(arch,'=',TAM_LINEA);
    arch<<setw(100)<<titulo<<endl<<fixed<<setprecision(2);
    imprimirLinea(arch,'=',TAM_LINEA);
    while (ptr) {
        struct Cliente datoCliente=ptr->cliente;
        arch<<setw(8)<<"DNI"<<setw(20)<<"NOMBRE"<<setw(42)<<"TIPO CLIENTE"<<setw(20)
                <<"CANT.CUENTAS"<<setw(15)<<" SALDO TOTAL"<<setw(20)<<"CANT.CUENTAS.HAB"
                <<setw(22)<<"CANT.CUENTAS.DESHAB"<<endl;
        arch<<setw(10)<<datoCliente.dni<<setw(3)<<' '<<left<<setw(40)
            <<datoCliente.nombre<<setw(13)<<datoCliente.tipoCliente
            <<right<<setw(18)<<datoCliente.cantidadCuentas<<setw(18)
            <<datoCliente.saldoTotal<<setw(16)
            <<datoCliente.cantidadCuentasHabilitadas
            <<setw(18)<<datoCliente.cantidadCuentasDeshabilitadas<<endl;
        imprimirLinea(arch,'-',TAM_LINEA);
        arch<<setw(10)<<"CUENTA"<<setw(20)<<"SALDO INICIAL"<<setw(10)<<"ESTADO"
               <<setw(16)<<"CANT.DEP"<<setw(12)<<"CANT.RET"
               <<setw(15)<<"SALDO FINAL"<<endl;
        imprimirLinea(arch,'-',TAM_LINEA);
        for (int j=0;j<datoCliente.cantidadCuentas;j++) {
            arch<<setw(10)<<datoCliente.cuentas[j].nroCuenta<<setw(18)
                <<datoCliente.cuentas[j].saldoInicial<<left<<setw(3)<<' '
                <<setw(15)<<datoCliente.cuentas[j].estado<<right
                <<setw(5)<<datoCliente.cuentas[j].cantidadDepositos
                <<setw(12)<<datoCliente.cuentas[j].cantidadRetiros
                <<setw(18)<<datoCliente.cuentas[j].saldoFinal<<endl;
        }
        ptr=ptr->siguiente;
        imprimirLinea(arch,'=',TAM_LINEA);
    }
}

void completarCuentas(const char *nombArch,struct NodoCliente *listaClientes){
    ifstream arch(nombArch,ios::in);
    if (not arch.is_open()) {
        cout<<"Error: el archivo "<<nombArch<<" no se pudo abrir"<<endl;
        exit(1);
    }
    int dni,cuenta,cantCuenta;
    double saldo;
    char c;
    struct NodoCliente *clienteEncontrado;
    while (true) {
        arch>>dni;
        if (arch.eof()) break;
        arch>>c>>cuenta>>c>>saldo;
        clienteEncontrado=buscarCliente(dni,listaClientes);
        if (clienteEncontrado) {
            cantCuenta=clienteEncontrado->cliente.cantidadCuentas;
            clienteEncontrado->cliente.cuentas[cantCuenta].nroCuenta=cuenta;
            clienteEncontrado->cliente.cuentas[cantCuenta].saldoInicial=saldo;
            clienteEncontrado->cliente.cuentas[cantCuenta].saldoFinal=saldo;
            actualizarEstado(saldo,clienteEncontrado->cliente.cuentas[cantCuenta].estado);
            clienteEncontrado->cliente.cantidadCuentas++;
        }
    }
}

struct NodoCliente* buscarCliente(int dni,struct NodoCliente *listaClientes){
    struct NodoCliente *ptr=listaClientes;
    while (ptr) {
        if (ptr->cliente.dni==dni)
            return ptr;
        else
            if (ptr->cliente.dni>dni)
                return nullptr;
        ptr=ptr->siguiente;
    }
    return nullptr;
}

void actualizarEstado(double saldo,char *estado){
    if (saldo>=0)
        strcpy(estado,"HABILITADO");
    else
        strcpy(estado,"INHABILITADO");
}

void completarTransacciones(const char *nombArch,struct NodoCliente *listaClientes){
    ifstream arch(nombArch,ios::in);
    if (not arch.is_open()) {
        cout<<"Error: el archivo "<<nombArch<<" no se pudo abrir"<<endl;
        exit(1);
    }
    int cuenta,posCuenta;
    struct NodoCliente *clienteEncontrado;
    char transc,c;
    double monto;
    while (true) {
        arch>>cuenta;
        if (arch.eof()) break;
        arch.get();
        buscarCuenta(cuenta, listaClientes,clienteEncontrado,posCuenta);
        if (clienteEncontrado and posCuenta!=NO_ENCONTRADO) {
            while (true) {
                arch>>transc>>c>>monto;
                if (transc=='D') {
                    clienteEncontrado->cliente.cuentas[posCuenta].saldoFinal+=monto;
                    clienteEncontrado->cliente.cuentas[posCuenta].cantidadDepositos++;
                }
                else {
                    clienteEncontrado->cliente.cuentas[posCuenta].saldoFinal-=monto;
                    clienteEncontrado->cliente.cuentas[posCuenta].cantidadRetiros++;
                }
                actualizarEstado(clienteEncontrado->cliente.cuentas[posCuenta].saldoFinal,
                        clienteEncontrado->cliente.cuentas[posCuenta].estado);
                if (arch.get()=='\n') break;
            }
        }
        else
             while (arch.get()!='\n');
    }
}

void buscarCuenta(int cuenta,struct NodoCliente *listaClientes,struct NodoCliente *&clienteEncontrado,
    int &posCuenta){
    struct NodoCliente *ptr=listaClientes;
    while (ptr) {
        int cant=ptr->cliente.cantidadCuentas;
        for (int i=0;i<cant;i++) {
            if (cuenta==ptr->cliente.cuentas[i].nroCuenta) {
                posCuenta=i;
                clienteEncontrado=ptr;
                return;
            }
        }
        ptr=ptr->siguiente;
    }
    clienteEncontrado=nullptr;
    posCuenta=NO_ENCONTRADO;
}


void imprimirLinea(ofstream &arch,char car,int cant){
    arch<<setfill(car)<<setw(cant)<<car<<setfill(' ')<<endl;
}

void actualizarInformacionCliente(struct NodoCliente *listaClientes){
    struct NodoCliente *ptr=listaClientes;
    double saldoTotal,cuentasHab,cuentasDeshab;
    while (ptr) {
        int cant=ptr->cliente.cantidadCuentas;
        saldoTotal=cuentasDeshab=cuentasHab=0;
        for (int i=0;i<cant;i++) {
            saldoTotal+=ptr->cliente.cuentas[i].saldoFinal;
            if (ptr->cliente.cuentas[i].saldoFinal<0)
                cuentasDeshab++;
            else
                cuentasHab++;
        }
        ptr->cliente.saldoTotal=saldoTotal;
        ptr->cliente.cantidadCuentasDeshabilitadas=cuentasDeshab;
        ptr->cliente.cantidadCuentasHabilitadas=cuentasHab;
        ptr=ptr->siguiente;
    }
}

void crearNuevasListas(struct NodoCliente *listaClientes,
    struct NodoCliente *&listaClientesSaldoPositivo,struct NodoCliente *&listaClientesSaldoNegativo){
    struct NodoCliente *ptr=listaClientes;
    inicializarLista(listaClientesSaldoPositivo);
    inicializarLista(listaClientesSaldoNegativo);
    while (ptr) {
        if (ptr->cliente.saldoTotal<0)
            insertarNodoOrdenado(ptr->cliente,listaClientesSaldoNegativo,false);
        else
            insertarNodoOrdenado(ptr->cliente,listaClientesSaldoPositivo,false);
        ptr=ptr->siguiente;
    }
}