#include "Bibliotecas/FuncionesAuxiliares.h"

//* RECORDAR DESCARGAR EN PLUGLINS BETTER COMMENTS PARA VER MEJOR LOS COMENTARIOS (COLORES Y ESO)
int main() {

    generar_reporte("ArchivosDeDatos/Lab2_twitchdataTP.csv", "ArchivosDeReporte/reporte.txt");

    return 0;
}
